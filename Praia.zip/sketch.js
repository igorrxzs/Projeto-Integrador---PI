let fundo, nuvem, reflexo, areia
let x1 = 0;
let x2 = 600;
let speed = 0.4;

function preload() {
  fundo = loadImage("./Imagens/1.png");
  nuvem = loadImage("./Imagens/2.png");
  reflexo = loadImage("./Imagens/3.png");
  areia = loadImage("./Imagens/areia.png");
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  image(fundo, 0, 0, 600, 400);
  image(nuvem, x1, 0, 600, 400);
  image(reflexo, x1, 0, 600, 400);
  image(nuvem, x2, 0, 600, 400);
  image(reflexo, x2, 0, 600, 400);
  image(areia, 0, 0, 600, 400);
  

  x1 -= speed;
  x2 -= speed;

  if (x1 <= -600) {
    x1 = x2 + 600;
  }

  if (x2 <= -600) {
    x2 = x1 + 600;
  }
}